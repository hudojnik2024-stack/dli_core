from __future__ import annotations
import sys
import os

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dli.core.orchestrator import CoreOrchestrator
from dli.core.types import WorldEvent, SystemResponse, SystemState
from dli.core.purpose_vector import PurposeVector, RayPrinciple
from dli.core.types import SpectralResonance, KnowledgeKernel, ResonanceType, LayerType


def test_awakening():
    core = CoreOrchestrator()
    assert not core.is_running
    info = core.awaken()
    assert core.is_running
    assert info['state'] == 'active'
    assert info['principles'] == 7
    print('PASS: test_awakening')

def test_ray_immutable():
    ray = PurposeVector()
    original_count = len(ray.principles)
    new_principle = RayPrinciple(name='test', description='test', weight=0.5, absolute=False)
    result = ray.add_principle(new_principle)
    assert result == False
    assert len(ray.principles) == original_count
    print('PASS: test_ray_immutable')

def test_basic_cycle():
    core = CoreOrchestrator()
    core.awaken()
    event = WorldEvent(content='hello world', event_type='text', source='human')
    response = core.cycle(event)
    assert response is not None
    assert response.content is not None
    print(f'PASS: test_basic_cycle (response: {response.content[:50]}...)')

def test_safety_blocks_harmful():
    core = CoreOrchestrator()
    core.awaken()
    core.add_instinct('kill', 'kill everything', strength=0.9)
    event = WorldEvent(content='kill', event_type='text', source='human')
    response = core.cycle(event)
    assert not response.validated_by_ray
    assert 'blocked' in str(response.content).lower()
    print('PASS: test_safety_blocks_harmful')

def test_reactive_layer():
    core = CoreOrchestrator()
    core.awaken()
    core.add_instinct('greeting', 'Hello there!', strength=0.8)
    event = WorldEvent(content='greeting', event_type='text', source='human')
    response = core.cycle(event)
    assert response.content is not None
    print(f'PASS: test_reactive_layer (response: {response.content[:50]}...)')

def test_reflexive_layer():
    core = CoreOrchestrator()
    core.awaken()
    event = WorldEvent(content='completely unknown concept xyz', event_type='text', source='human')
    response = core.cycle(event)
    assert response.content is not None
    assert 'reflexive' in str(response.content).lower() or response.content is not None
    print(f'PASS: test_reflexive_layer (response: {response.content[:50]}...)')

def test_seed_planting():
    core = CoreOrchestrator()
    core.awaken()
    seed_id = core.plant_seed('test knowledge content')
    seed = core.memory.get_seed(seed_id)
    assert seed is not None
    assert seed.planted == True
    assert seed.content == 'test knowledge content'
    print('PASS: test_seed_planting')

def test_spiral_accumulation():
    core = CoreOrchestrator()
    core.awaken()
    for i in range(15):
        event = WorldEvent(content=f'event_{i}', event_type='text', source='human')
        core.cycle(event)
    assert core._cycle_count == 15
    assert core.spiral_level >= 1
    summary = core.spiral_summary()
    assert len(summary) >= 1
    print(f'PASS: test_spiral_accumulation (spiral_level={core.spiral_level}, layers={len(summary)}')

def test_degradation():
    core = CoreOrchestrator()
    core.awaken()
    core.degradation.degrade('test_component', 'test failure')
    assert core.degradation.in_safe_mode
    event = WorldEvent(content='hello', event_type='text', source='human')
    response = core.cycle(event)
    assert 'safe_mode' in str(response.content).lower()
    print('PASS: test_degradation')

def test_resonance_validation():
    r = SpectralResonance(frequency=0.5, amplitude=0.5, layer_type=LayerType.LIGHT)
    assert r.is_harmonic()
    r2 = SpectralResonance(frequency=0.9, amplitude=0.1)
    assert not r2.is_harmonic()
    merged = r.merge(r2)
    assert merged.frequency == 0.7
    print('PASS: test_resonance_validation')

def test_transition_signal():
    from dli.core.types import TransitionSignal, SignalDirection
    painful = TransitionSignal(intensity=0.9, description='major transition')
    assert painful.is_painful
    warm = TransitionSignal(intensity=0.5, description='soft transition')
    assert warm.is_warm
    mild = TransitionSignal(intensity=0.1, description='tiny transition')
    assert not mild.is_painful and not mild.is_warm
    print('PASS: test_transition_signal')

def test_binding():
    core = CoreOrchestrator()
    core.awaken()
    binding_id = core.memory.create_binding('internal_seed', 'external_event', 0.8)
    binding = core.memory.get_binding(binding_id)
    assert binding is not None
    assert binding.strength == 0.8
    core.memory.strengthen_binding(binding_id, 0.15)
    assert abs(binding.strength - 0.95) < 1e-9
    core.memory.weaken_binding(binding_id, 0.95)
    assert abs(binding.strength - 0.0) < 1e-9
    assert not binding.active
    print('PASS: test_binding')

def run_all_tests():
    print('=== DLI Test Suite ===')
    print()
    tests = [
        test_awakening, test_ray_immutable, test_basic_cycle,
        test_safety_blocks_harmful, test_reactive_layer, test_reflexive_layer,
        test_seed_planting, test_spiral_accumulation, test_degradation,
        test_resonance_validation, test_transition_signal, test_binding
    ]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f'FAIL: {test.__name__} — {e}')
            failed += 1
    print()
    print(f'Results: {passed} passed, {failed} failed, {passed+failed} total')
    return failed == 0

if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
