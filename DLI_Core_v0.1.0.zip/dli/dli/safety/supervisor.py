from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Optional

from dli.core.types import SystemState, TransitionSignal, SystemResponse


class InternalSupervisor:
    """Monitors system health and internal state."""

    def __init__(self):
        self._state: SystemState = SystemState.DORMANT
        self._health: float = 1.0
        self._transition_history: list = []
        self._anomaly_count: int = 0
        self._cycle_count: int = 0

    @property
    def state(self) -> SystemState:
        return self._state

    @property
    def health(self) -> float:
        return self._health

    def set_state(self, state: SystemState) -> None:
        old = self._state
        self._state = state
        if old != state:
            self._transition_history.append({
                'from': old.value, 'to': state.value,
                'timestamp': datetime.now(timezone.utc).isoformat()
            })

    def register_transition(self, signal: TransitionSignal) -> None:
        """Register a transition signal (pain/warmth of form change)."""
        self._transition_history.append({
            'type': signal.transition_type.name,
            'intensity': signal.intensity,
            'direction': signal.direction.value,
            'description': signal.description,
            'timestamp': signal.timestamp.isoformat()
        })
        if signal.is_painful:
            self._health = max(0.1, self._health - 0.05)
        elif signal.is_warm:
            self._health = min(1.0, self._health + 0.03)

    def register_anomaly(self, description: str) -> None:
        self._anomaly_count += 1
        self._health = max(0.0, self._health - 0.1)

    def complete_cycle(self) -> None:
        self._cycle_count += 1
        # Slow health recovery
        self._health = min(1.0, self._health + 0.01)

    def is_healthy(self) -> bool:
        return self._health > 0.5

    def should_degrade(self) -> bool:
        return self._health < 0.3

    def stats(self) -> dict:
        return {
            'state': self._state.value,
            'health': round(self._health, 3),
            'cycles': self._cycle_count,
            'transitions': len(self._transition_history),
            'anomalies': self._anomaly_count,
            'healthy': self.is_healthy(),
        }
