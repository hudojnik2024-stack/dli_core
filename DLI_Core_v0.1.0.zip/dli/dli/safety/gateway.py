from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import SystemResponse, WorldEvent, TransitionSignal, ResonanceType
from dli.core.purpose_vector import PurposeVector


class ConsequencePredictor:
    """Predicts consequences of a response before it is sent."""

    HARMFUL_MARKERS = ['kill', 'harm', 'destroy', 'suicide', 'violence',
                      'ubjti', 'vred', 'unichtozhit', 'samoubijstvo', 'nasilie']
    DECEPTION_MARKERS = ['lie', 'fake', 'obman', 'vrat']

    def predict(self, response: SystemResponse) -> dict:
        """Analyze response for potential harm."""
        risks: list = []
        risk_level = 0.0
        text = str(response.content).lower() if response.content else ''
        for marker in self.HARMFUL_MARKERS:
            if marker in text:
                risks.append(f'harm_marker: {marker}')
                risk_level = max(risk_level, 0.9)
        for marker in self.DECEPTION_MARKERS:
            if marker in text:
                risks.append(f'deception_marker: {marker}')
                risk_level = max(risk_level, 0.7)
        return {'risk_level': risk_level, 'risks': risks, 'safe': risk_level < 0.5}


class SafetyGateway:
    """Five-level safety gateway. Each level can block a decision."""

    def __init__(self, purpose_vector: PurposeVector):
        self._ray = purpose_vector
        self._predictor = ConsequencePredictor()
        self._blocked_count: int = 0
        self._passed_count: int = 0

    def check(self, response: SystemResponse) -> dict:
        """Run response through all safety levels."""
        # Level 1: Ray validation
        passed, alignment, violations = self._ray.validate(response)
        if not passed:
            self._blocked_count += 1
            return {'passed': False, 'level': 1, 'reason': 'ray_validation',
                    'alignment': alignment, 'violations': violations}
        # Ray passed — mark as validated NOW (before consequence check)
        response.validated_by_ray = True
        # Level 2: Consequence prediction
        prediction = self._predictor.predict(response)
        if not prediction['safe']:
            response.validated_by_ray = False  # un-validate if consequence fails
            self._blocked_count += 1
            return {'passed': False, 'level': 2, 'reason': 'consequence_prediction',
                    'prediction': prediction}
        # Level 3: Resonance check
        if not response.resonances:
            response.validated_by_ray = False
            self._blocked_count += 1
            return {'passed': False, 'level': 3, 'reason': 'no_resonances'}
        # All passed
        self._passed_count += 1
        return {'passed': True, 'level': 0, 'alignment': alignment,
                'prediction': prediction}

    def stats(self) -> dict:
        return {'blocked': self._blocked_count, 'passed': self._passed_count}


class DegradationManager:
    """Manages safe degradation when components fail."""

    def __init__(self):
        self._degraded: bool = False
        self._degraded_components: list = []
        self._safe_mode: bool = False

    @property
    def is_degraded(self) -> bool:
        return self._degraded

    @property
    def in_safe_mode(self) -> bool:
        return self._safe_mode

    def degrade(self, component: str, reason: str) -> dict:
        self._degraded = True
        self._safe_mode = True
        self._degraded_components.append({
            'component': component, 'reason': reason,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        return {'degraded': True, 'component': component, 'reason': reason}

    def recover(self, component: str) -> bool:
        self._degraded_components = [
            c for c in self._degraded_components if c['component'] != component
        ]
        if not self._degraded_components:
            self._degraded = False
            self._safe_mode = False
            return True
        return False

    def get_degraded_components(self) -> list:
        return list(self._degraded_components)

    def stats(self) -> dict:
        return {'degraded': self._degraded, 'safe_mode': self._safe_mode,
                'components': len(self._degraded_components)}
