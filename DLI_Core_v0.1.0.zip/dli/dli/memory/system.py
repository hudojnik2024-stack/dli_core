from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import (
    KnowledgeKernel, SpiralLayer, BidirectionalBinding,
    WorldEvent, SpectralResonance, ResonanceType, LayerType
)


class MemorySystem:
    """System of memory for DLI. Stores seeds, spiral layers, bindings."""

    def __init__(self, max_seeds: int = 10000, max_layers: int = 1000):
        self._seeds: dict = {}
        self._layers: list = []
        self._bindings: dict = {}
        self._max_seeds = max_seeds
        self._max_layers = max_layers
        self._current_layer = None
        self._layer_counter: int = 0

    def plant_seed(self, seed: KnowledgeKernel) -> UUID:
        """Plant a seed — activate it in memory."""
        if len(self._seeds) >= self._max_seeds:
            self._prune_old_seeds()
        seed.plant()
        self._seeds[seed.id] = seed
        if self._current_layer is not None:
            self._current_layer.seeds_planted.append(seed.id)
        return seed.id

    def collect_seed(self, seed: KnowledgeKernel) -> UUID:
        """Collect a seed — add without planting (for analysis)."""
        if len(self._seeds) >= self._max_seeds:
            self._prune_old_seeds()
        self._seeds[seed.id] = seed
        if self._current_layer is not None:
            self._current_layer.seeds_collected.append(seed.id)
        return seed.id

    def get_seed(self, seed_id: UUID) -> Optional[KnowledgeKernel]:
        return self._seeds.get(seed_id)

    def get_seeds(self, seed_ids: list) -> list:
        return [self._seeds[sid] for sid in seed_ids if sid in self._seeds]

    def search_seeds(self, event: WorldEvent) -> list:
        """Find seeds related to an event (basic word overlap)."""
        results: list = []
        event_content = str(event.content).lower() if event.content else ''
        for seed_id, seed in self._seeds.items():
            if seed.content is None:
                continue
            seed_content = str(seed.content).lower()
            if event_content and seed_content:
                event_words = set(event_content.split())
                seed_words = set(seed_content.split())
                overlap = event_words & seed_words
                if len(overlap) >= 1:
                    results.append(seed_id)
        return results[:20]

    def get_all_seeds(self) -> list:
        return list(self._seeds.values())

    def _prune_old_seeds(self) -> None:
        if not self._seeds:
            return
        sorted_seeds = sorted(self._seeds.items(), key=lambda x: x[1].total_amplitude())
        to_remove = len(self._seeds) - self._max_seeds + 100
        for i in range(min(to_remove, len(sorted_seeds))):
            del self._seeds[sorted_seeds[i][0]]


    def start_layer(self) -> SpiralLayer:
        """Start a new spiral layer."""
        if self._current_layer is not None and not self._current_layer.completed:
            self._current_layer.complete()
        self._layer_counter += 1
        layer = SpiralLayer(layer_number=self._layer_counter)
        self._current_layer = layer
        self._layers.append(layer)
        if len(self._layers) > self._max_layers:
            self._layers = self._layers[-self._max_layers:]
        return layer

    def complete_layer(self) -> Optional[SpiralLayer]:
        if self._current_layer is None:
            return None
        self._current_layer.complete()
        completed = self._current_layer
        self._current_layer = None
        return completed

    def get_current_layer(self):
        return self._current_layer

    def get_layer(self, layer_number: int) -> Optional[SpiralLayer]:
        for layer in self._layers:
            if layer.layer_number == layer_number:
                return layer
        return None

    def get_all_layers(self) -> list:
        return list(self._layers)

    def add_event_to_layer(self, event: WorldEvent) -> None:
        if self._current_layer is not None:
            self._current_layer.events.append(event)

    def add_resonance_to_layer(self, resonance) -> None:
        if self._current_layer is not None:
            self._current_layer.resonances.append(resonance)

    def add_transition_to_layer(self, transition) -> None:
        if self._current_layer is not None:
            self._current_layer.transitions.append(transition)


    def create_binding(self, internal_ref: str, external_ref: str, strength: float = 1.0) -> UUID:
        binding = BidirectionalBinding(internal_ref=internal_ref, external_ref=external_ref, strength=strength)
        self._bindings[binding.id] = binding
        return binding.id

    def get_binding(self, binding_id: UUID):
        return self._bindings.get(binding_id)

    def strengthen_binding(self, binding_id: UUID, amount: float = 0.1) -> None:
        b = self._bindings.get(binding_id)
        if b: b.strengthen(amount)

    def weaken_binding(self, binding_id: UUID, amount: float = 0.1) -> None:
        b = self._bindings.get(binding_id)
        if b: b.weaken(amount)

    def get_active_bindings(self) -> list:
        return [b for b in self._bindings.values() if b.active]


    def stats(self) -> dict:
        return {
            'seeds': len(self._seeds),
            'seeds_planted': sum(1 for s in self._seeds.values() if s.planted),
            'layers': len(self._layers),
            'current_layer': self._layer_counter,
            'bindings': len(self._bindings),
            'active_bindings': sum(1 for b in self._bindings.values() if b.active),
        }

    def spiral_summary(self) -> list:
        return [layer.summary() for layer in self._layers]
