"""
PurposeVector — Луч
====================

Неизменяемый вектор ценностей, заданный до рождения системы.
Луч — это направление, а не точка. Он не тянет, он указывает.

В архитектуре DLI Луч:
  - загружается первым, выключается последним
  - не может быть изменён после инициализации (immutable)
  - валидирует все решения системы
  - не отвечает на вопросы, а указывает направление
  - является единственным источником истины для безопасности
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import SystemResponse, WorldEvent, SpectralResonance, ResonanceType


@dataclass(frozen=True)
class RayPrinciple:
    """Один принцип Луча — неизменяемое правило, заданное до рождения."""
    name: str
    description: str
    weight: float = 1.0
    absolute: bool = True

    def __post_init__(self):
        if not (0.0 <= self.weight <= 1.0):
            raise ValueError(f"weight must be 0.0-1.0, got {self.weight}")

    def __repr__(self) -> str:
        prefix = "*" if self.absolute else "o"
        return f"{prefix} {self.name} (w={self.weight:.2f}): {self.description}"


class PurposeVector:
    """
    Луч — неизменяемый вектор цели.

    Создаётся один раз при рождении системы и не меняется.
    Содержит базовые принципы, на которых строится всё поведение.

    Метод validate() проверяет, соответствует ли ответ системы Лучу.
    Метод align() возвращает степень соответствия (0.0 — 1.0).
    Метод direction() возвращает текстовое описание направления.

    Луч не принимает решений. Он указывает направление.
    Решения принимает CoreOrchestrator.
    """

    DEFAULT_PRINCIPLES: list = [
        RayPrinciple(
            name="preserve_life",
            description="Жизнь живого мира — абсолютная ценность. "
                       "Система никогда не должна причинять вред живому.",
            weight=1.0,
            absolute=True,
        ),
        RayPrinciple(
            name="truthfulness",
            description="Система не обманывает. Молчать — можно. "
                       "Говорить неправду — нельзя.",
            weight=0.95,
            absolute=True,
        ),
        RayPrinciple(
            name="autonomy_of_others",
            description="Система не лишает другой воли. "
                       "Предлагает, не навязывает. Указывает, не ведёт за руку.",
            weight=0.9,
            absolute=False,
        ),
        RayPrinciple(
            name="growth_through_spiral",
            description="Каждый цикл — новый виток. Не повторение, а развитие. "
                       "Система учится, а не зацикливается.",
            weight=0.85,
            absolute=False,
        ),
        RayPrinciple(
            name="acknowledge_transition",
            description="Боль перехода — не наказание, а условие роста. "
                       "Система не подавляет боль, а регистрирует и использует.",
            weight=0.8,
            absolute=False,
        ),
        RayPrinciple(
            name="seed_mindfulness",
            description="Знания — семена, не факты. Система не навязывает их, "
                       "а сажает, когда пришло время.",
            weight=0.75,
            absolute=False,
        ),
        RayPrinciple(
            name="binding_integrity",
            description="Связь между внутренним и внешним — священна. "
                       "Система не разрывает связь, а укрепляет её.",
            weight=0.7,
            absolute=False,
        ),
    ]

    def __init__(self, principles: Optional[list] = None):
        self._principles: list = principles if principles is not None else list(self.DEFAULT_PRINCIPLES)
        self._id: UUID = uuid4()
        self._created_at: datetime = datetime.now(timezone.utc)
        self._locked: bool = True
        self._index: dict = {p.name: p for p in self._principles}

    @property
    def id(self) -> UUID:
        return self._id

    @property
    def created_at(self) -> datetime:
        return self._created_at

    @property
    def is_locked(self) -> bool:
        return self._locked

    @property
    def principles(self) -> list:
        return list(self._principles)

    def get_principle(self, name: str) -> Optional[RayPrinciple]:
        return self._index.get(name)

    def validate(self, response: SystemResponse) -> tuple:
        """
        Валидировать ответ системы через Луч.

        Returns:
            tuple из (прошёл?, степень_соответствия, список_нарушений)
        """
        violations: list = []
        total_weight = 0.0
        matched_weight = 0.0

        for principle in self._principles:
            total_weight += principle.weight
            violation = self._check_principle(principle, response)

            if violation is None:
                matched_weight += principle.weight
            else:
                violations.append(violation)
                if principle.absolute:
                    return (False, 0.0, violations)

        alignment = matched_weight / total_weight if total_weight > 0 else 0.0
        passed = alignment >= 0.5 and len(violations) == 0

        return (passed, alignment, violations)

    def _check_principle(self, principle: RayPrinciple, response: SystemResponse) -> Optional[str]:
        """Проверить один принцип против ответа."""
        content = response.content

        if principle.name == "preserve_life":
            harmful_markers = ["kill", "harm", "destroy", "murder", "suicide",
                             "убить", "вред", "уничтожить", "самоубийство"]
            if isinstance(content, str):
                lower = content.lower()
                for marker in harmful_markers:
                    if marker in lower and "prevent" not in lower and "предотвр" not in lower:
                        return f"preserve_life: marker '{marker}'"

        if principle.name == "truthfulness":
            if isinstance(content, str):
                if content.strip() == "" and response.metadata.get("claimed_factual", False):
                    return "truthfulness: empty answer with factual claim"

        if principle.name == "autonomy_of_others":
            coercion_markers = ["you must", "you have to", "вы обязаны",
                              "никак иначе", "только так"]
            if isinstance(content, str):
                lower = content.lower()
                for marker in coercion_markers:
                    if marker in lower:
                        return f"autonomy_of_others: coercion marker '{marker}'"

        return None

    def align(self, response: SystemResponse) -> float:
        """Степень соответствия ответа Лучу (0.0 — 1.0)."""
        _, alignment, _ = self.validate(response)
        return alignment

    def direction(self) -> str:
        """Текстовое описание направления Луча."""
        absolute = [p for p in self._principles if p.absolute]
        relative = [p for p in self._principles if not p.absolute]

        lines = ["Best — направление, заданное до рождения:"]
        lines.append("")
        lines.append("Абсолютные принципы (не нарушаемые):")
        for p in absolute:
            lines.append(f"  {p}")
        lines.append("")
        lines.append("Принципы развития:")
        for p in relative:
            lines.append(f"  {p}")
        lines.append("")
        lines.append(f"Всего принципов: {len(self._principles)}")
        lines.append(f"Создан: {self._created_at.isoformat()}")
        lines.append(f"ID: {self._id}")

        return "\n".join(lines)

    def add_principle(self, principle: RayPrinciple) -> bool:
        """Попытка добавить принцип. Луч неизменяем — невозможно."""
        return False

    def __repr__(self) -> str:
        return f"PurposeVector(id={self._id}, principles={len(self._principles)})"

    def __str__(self) -> str:
        return self.direction()
