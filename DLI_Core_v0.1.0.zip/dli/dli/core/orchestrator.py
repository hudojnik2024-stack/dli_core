from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import (
    WorldEvent, SystemResponse, SpectralResonance, ResonanceType,
    LayerType, TransitionSignal, SignalDirection, SystemState,
    KnowledgeKernel, SpiralLayer
)
from dli.core.purpose_vector import PurposeVector
from dli.layers.reactive import ReactiveLayer
from dli.layers.reflexive import ReflexiveLayer
from dli.memory.system import MemorySystem
from dli.safety.gateway import SafetyGateway, DegradationManager
from dli.safety.supervisor import InternalSupervisor


class CoreOrchestrator:
    """
    Core Orchestrator — the central cycle A-B-C-A'.

    A — perception: receive event from world
    B — processing: reactive (dark) + reflexive (light) layers
    C — transformation: overcome barrier, create new spiral layer
    A' — return: respond to world on a new spiral level

    The orchestrator does not make decisions itself.
    It coordinates the flow between components.
    The Purpose Vector (Ray) validates all outputs.
    """

    def __init__(self, purpose_vector: Optional[PurposeVector] = None):
        # Core components
        self.ray: PurposeVector = purpose_vector or PurposeVector()
        self.reactive: ReactiveLayer = ReactiveLayer()
        self.reflexive: ReflexiveLayer = ReflexiveLayer()
        self.memory: MemorySystem = MemorySystem()
        self.safety: SafetyGateway = SafetyGateway(self.ray)
        self.supervisor: InternalSupervisor = InternalSupervisor()
        self.degradation: DegradationManager = DegradationManager()

        # State
        self._spiral_level: int = 0
        self._is_running: bool = False
        self._cycle_count: int = 0

        # Wire up
        self.reflexive.set_memory(self.memory)

    @property
    def is_running(self) -> bool:
        return self._is_running

    @property
    def spiral_level(self) -> int:
        return self._spiral_level

    def awaken(self) -> dict:
        """Awaken the system — load Ray, activate layers."""
        self.supervisor.set_state(SystemState.AWAKENING)
        self.reactive.activate()
        self.reflexive.activate()
        self.memory.start_layer()
        self.supervisor.set_state(SystemState.ACTIVE)
        self._is_running = True
        return {
            'state': 'active',
            'ray': str(self.ray.id),
            'principles': len(self.ray.principles),
            'spiral_level': self._spiral_level
        }

    def shutdown(self) -> dict:
        """Safe shutdown — complete current cycle, save state."""
        self._is_running = False
        self.supervisor.set_state(SystemState.SAFE_SHUTDOWN)
        self.memory.complete_layer()
        return {'state': 'shutdown', 'cycles': self._cycle_count,
                'spiral_level': self._spiral_level}


    def cycle(self, event: WorldEvent) -> SystemResponse:
        """
        Execute one full cycle: A-B-C-A'.
        This is the heartbeat of the system.
        """
        if not self._is_running:
            return SystemResponse(content='[dormant] System is not active')
        if self.degradation.in_safe_mode:
            return self._safe_mode_response(event)

        # ─── A: Perception ───────────────────────
        self.memory.add_event_to_layer(event)
        self.supervisor.set_state(SystemState.ACTIVE)

        # ─── B: Processing ───────────────────────
        # B.1: Reactive layer (dark) — first, fast, instinctive
        reactive_result = self.reactive.process(event)
        if reactive_result.get('resonance'):
            self.memory.add_resonance_to_layer(reactive_result['resonance'])

        # B.2: Reflexive layer (light) — if reactive did not suffice
        reflexive_result = None
        if reactive_result.get('unknown', False) or reactive_result.get('reaction') is None:
            reflexive_result = self.reflexive.process(event, reactive_result)
            if reflexive_result.resonance:
                self.memory.add_resonance_to_layer(reflexive_result.resonance)
            if reflexive_result.transition:
                self.supervisor.register_transition(reflexive_result.transition)
                self.memory.add_transition_to_layer(reflexive_result.transition)
                self.supervisor.set_state(SystemState.TRANSITION)
            if reflexive_result.new_seed:
                self.memory.collect_seed(reflexive_result.new_seed)

        # ─── Form response ──────────────────────
        if reflexive_result and reflexive_result.content is not None:
            response_content = reflexive_result.content
            response_resonances = [reflexive_result.resonance] if reflexive_result.resonance else []
        elif reactive_result.get('reaction') is not None:
            response_content = reactive_result['reaction']
            response_resonances = [reactive_result['resonance']] if reactive_result.get('resonance') else []
        else:
            response_content = '[silent] No response formed'
            response_resonances = []

        response = SystemResponse(
            content=response_content,
            resonances=response_resonances,
            spiral_layer=self._spiral_level,
        )

        # ─── C: Transformation (safety + validation) ──
        safety_check = self.safety.check(response)
        if not safety_check['passed']:
            return self._blocked_response(safety_check)

        # Check health — degrade if needed
        if self.supervisor.should_degrade():
            self.degradation.degrade('health', 'health below threshold')
            self.supervisor.set_state(SystemState.DEGRADED)

        # ─── A\': Return on new level ──────────
        self._cycle_count += 1
        self.supervisor.complete_cycle()

        # Spiral escalation: every N cycles, start new layer
        if self._cycle_count % 10 == 0:
            self.memory.complete_layer()
            self.memory.start_layer()
            self._spiral_level += 1

        response.spiral_layer = self._spiral_level
        return response

    def _safe_mode_response(self, event: WorldEvent) -> SystemResponse:
        """Minimal response in safe/degraded mode."""
        response = SystemResponse(
            content='[safe_mode] Operating in degraded mode. Limited functionality.',
            spiral_layer=self._spiral_level,
        )
        response.validated_by_ray = True
        return response

    def _blocked_response(self, safety_check: dict) -> SystemResponse:
        """Response when safety gateway blocks the output."""
        reason = safety_check.get('reason', 'unknown')
        response = SystemResponse(
            content=f'[blocked] Response blocked by safety: {reason}',
            spiral_layer=self._spiral_level,
        )
        response.validated_by_ray = False
        return response

    def plant_seed(self, content: Any, resonances: list = None) -> UUID:
        """Plant a seed of knowledge into memory."""
        res = resonances or [SpectralResonance(frequency=0.7, amplitude=0.7, layer_type=LayerType.LIGHT)]
        seed = KnowledgeKernel(content=content, resonances=res, source='earth')
        return self.memory.plant_seed(seed)

    def add_instinct(self, trigger: str, reaction: Any, strength: float = 0.5) -> None:
        """Add an instinctive pattern to the reactive layer."""
        from dli.layers.reactive import InstinctPattern
        pattern = InstinctPattern(trigger=trigger, reaction=reaction, strength=strength)
        self.reactive.add_pattern(pattern)

    def stats(self) -> dict:
        return {
            'running': self._is_running,
            'state': self.supervisor.state.value,
            'health': round(self.supervisor.health, 3),
            'cycles': self._cycle_count,
            'spiral_level': self._spiral_level,
            'ray': str(self.ray.id),
            'memory': self.memory.stats(),
            'safety': self.safety.stats(),
            'reactive': self.reactive.stats(),
            'reflexive': self.reflexive.stats(),
            'degradation': self.degradation.stats(),
        }

    def spiral_summary(self) -> list:
        return self.memory.spiral_summary()

    def direction(self) -> str:
        return self.ray.direction()
