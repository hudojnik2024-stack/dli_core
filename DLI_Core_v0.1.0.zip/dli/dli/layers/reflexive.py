"""
ReflexiveLayer — Свет
======================

Рефлексивный слой — осознанная обработка.
Это "светлая" сторона бытия: медленная, аналитическая,
требующая осознания. Как луч, который прожёг сознание
и пробудил спящую часть.

Рефлексивный слой:
  - включается, когда реактивный слой не справился (событие неизвестно)
  - анализирует событие, ищет связи с семенами памяти
  - формирует осознанный ответ
  - может создать новое семя знания
  - может инициировать переход (сигнал боли/тепла)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import (
    WorldEvent, SpectralResonance, ResonanceType,
    LayerType, TransitionSignal, SignalDirection, KnowledgeKernel
)


@dataclass
class AnalysisResult:
    """
    Результат анализа рефлексивного слоя.
    
    Содержит:
      - осознанный ответ (content)
      - резонанс ответа
      - обнаруженные связи с семенами
      - сигнал перехода (если анализ потребовал смены формы)
      - новое семя (если в процессе анализа родилось знание)
    """
    content: Any = None
    resonance: Optional[SpectralResonance] = None
    linked_seeds: list[UUID] = field(default_factory=list)
    transition: Optional[TransitionSignal] = None
    new_seed: Optional[KnowledgeKernel] = None
    confidence: float = 0.0
    
    def __post_init__(self):
        if not (0.0 <= self.confidence <= 1.0):
            raise ValueError(f"confidence must be 0.0-1.0, got {self.confidence}")


class ReflexiveLayer:
    """
    Рефлексивный слой (Свет) — осознанная обработка.
    
    Включается, когда реактивный слой не нашёл ответа.
    Анализирует событие через память, ищет связи,
    формирует осознанный ответ.
    
    Если событие принципиально новое — создаёт семя.
    Если анализ требует смены режима — инициирует переход.
    """
    
    def __init__(self, memory_system=None):
        self._memory = memory_system
        self._is_active: bool = False
        self._analysis_log: list[dict] = []
        self._transition_threshold: float = 0.7  # порог боли перехода
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    def activate(self) -> None:
        """Пробудить рефлексивный слой."""
        self._is_active = True
    
    def deactivate(self) -> None:
        """Усыпить рефлексивный слой."""
        self._is_active = False
    
    def set_memory(self, memory_system) -> None:
        """Привязать систему памяти."""
        self._memory = memory_system
    
    def process(self, event: WorldEvent, reactive_result: dict) -> AnalysisResult:
        """
        Обработать событие рефлексивным слоем.
        
        Args:
            event: событие из мира
            reactive_result: результат реактивного слоя
            
        Returns:
            AnalysisResult — результат анализа
        """
        if not self._is_active:
            return AnalysisResult(
                content=None,
                confidence=0.0,
                resonance=SpectralResonance(
                    frequency=0.0, amplitude=0.0,
                    layer_type=LayerType.LIGHT
                )
            )
        
        # Поиск связанных семян в памяти
        linked_seeds: list[UUID] = []
        if self._memory is not None:
            linked_seeds = self._memory.search_seeds(event)
        
        # Формирование ответа
        content = self._form_response(event, reactive_result, linked_seeds)
        
        # Определение резонанса
        resonance = SpectralResonance(
            frequency=0.8,  # высокая частота — свет
            amplitude=0.7,
            layer_type=LayerType.LIGHT,
            metadata={"linked_seeds": len(linked_seeds)}
        )
        
        # Проверка на необходимость перехода
        transition = None
        if reactive_result.get("unknown", False) and len(linked_seeds) == 0:
            # Полностью неизвестное событие — возможен переход
            intensity = self._calculate_transition_intensity(event, reactive_result)
            if intensity > 0:
                transition = TransitionSignal(
                    transition_type=ResonanceType.TRANSITION,
                    intensity=intensity,
                    direction=SignalDirection.INWARD,
                    description=f"New event type: {event.event_type}"
                )
        
        # Создание нового семени, если событие новое
        new_seed = None
        if reactive_result.get("unknown", False) and content is not None:
            new_seed = KnowledgeKernel(
                content=content,
                resonances=[resonance],
                growth_potential=0.5,
                source="earth",
            )
        
        confidence = self._calculate_confidence(linked_seeds, reactive_result)
        
        result = AnalysisResult(
            content=content,
            resonance=resonance,
            linked_seeds=linked_seeds,
            transition=transition,
            new_seed=new_seed,
            confidence=confidence,
        )
        
        self._analysis_log.append({
            "event_id": str(event.id),
            "confidence": confidence,
            "linked_seeds": len(linked_seeds),
            "transition": transition is not None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        
        return result
    
    def _form_response(self, event: WorldEvent, reactive_result: dict, 
                       linked_seeds: list[UUID]) -> Any:
        """Сформировать осознанный ответ."""
        if linked_seeds and self._memory is not None:
            # Есть связи с семенами — построить ответ на основе памяти
            seeds = self._memory.get_seeds(linked_seeds)
            if seeds:
                seed_contents = [s.content for s in seeds if s.content is not None]
                if seed_contents:
                    return self._synthesize(event, seed_contents)
        
        if reactive_result.get("reaction") is not None:
            return reactive_result["reaction"]
        
        # Базовый ответ
        if isinstance(event.content, str):
            return f"[reflexive] Понял: {event.content}"
        return f"[reflexive] Обработано событие типа {event.event_type}"
    
    def _synthesize(self, event: WorldEvent, seed_contents: list) -> Any:
        """Синтез ответа из содержимого семян."""
        if not seed_contents:
            return None
        
        if isinstance(event.content, str):
            combined = " | ".join(str(c) for c in seed_contents[:3])
            return f"[reflexive] {event.content} -> {combined}"
        
        return seed_contents[0]
    
    def _calculate_transition_intensity(self, event: WorldEvent, 
                                        reactive_result: dict) -> float:
        """Вычислить интенсивность перехода (0.0 — 1.0)."""
        base = 0.3
        if reactive_result.get("unknown", False):
            base += 0.2
        if event.event_type not in ("text", "signal"):
            base += 0.2
        return min(base, 1.0)
    
    def _calculate_confidence(self, linked_seeds: list, 
                               reactive_result: dict) -> float:
        """Вычислить уверенность в ответе."""
        if linked_seeds:
            return min(0.5 + len(linked_seeds) * 0.15, 1.0)
        if reactive_result.get("matched", False):
            return 0.6
        return 0.3  # низкая уверенность для нового
    
    def stats(self) -> dict:
        """Статистика слоя."""
        return {
            "active": self._is_active,
            "analyses": len(self._analysis_log),
            "transitions": sum(1 for a in self._analysis_log if a.get("transition")),
        }
