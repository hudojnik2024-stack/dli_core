"""
ReactiveLayer — Тьма
=====================

Реактивный слой — первичная обработка входящих событий.
Это "тёмная" сторона бытия: быстрая, инстинктивная, 
не требующая осознания. Как спящая часть сознания, которая
вросла в материю и реагает на стимулы напрямую.

Реактивный слой:
  - первым воспринимает событие из мира
  - формирует первичную реакцию (без анализа)
  - не принимает решений, а предлагает реакции
  - может быть переопределён рефлексивным слоем
  - хранит инстинктивные шаблоны (вросшие в материю)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID, uuid4

from dli.core.types import (
    WorldEvent, SpectralResonance, ResonanceType, 
    LayerType, TransitionSignal, SignalDirection
)


@dataclass
class InstinctPattern:
    """
    Инстинктивный шаблон — вросшая в материю реакция.
    
    Аналог: спящее существо во тьме, которое реагирует на свет
    слепой яростью, не зная, что этот свет — часть его самого.
    
    Шаблон срабатывает, когда входящее событие совпадает
    с его триггером. Реакция формируется мгновенно, без анализа.
    """
    id: UUID = field(default_factory=uuid4)
    trigger: str = ""
    reaction: Any = None
    strength: float = 0.5
    layer_type: LayerType = LayerType.DARK
    activated_count: int = 0
    
    def matches(self, event: WorldEvent) -> bool:
        """Проверяет, совпадает ли событие с триггером шаблона."""
        if isinstance(event.content, str) and self.trigger:
            return self.trigger.lower() in event.content.lower()
        return False
    
    def activate(self) -> Any:
        """Активировать шаблон — вернуть реакцию."""
        self.activated_count += 1
        return self.reaction


class ReactiveLayer:
    """
    Реактивный слой (Тьма) — первичная обработка.
    
    Получает событие, ищет совпадение с инстинктивными шаблонами,
    формирует первичную реакцию. Если шаблона нет — возвращает
    сигнал "неизвестное" для передачи в рефлексивный слой.
    
    Реактивный слой не ошибается — он просто не знает.
    Не знать — это нормально для тьмы.
    """
    
    def __init__(self):
        self._patterns: list[InstinctPattern] = []
        self._activation_log: list[dict] = []
        self._is_active: bool = False
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    def activate(self) -> None:
        """Пробудить реактивный слой."""
        self._is_active = True
    
    def deactivate(self) -> None:
        """Усыпить реактивный слой (безопасный режим)."""
        self._is_active = False
    
    def add_pattern(self, pattern: InstinctPattern) -> None:
        """Добавить инстинктивный шаблон."""
        self._patterns.append(pattern)
    
    def process(self, event: WorldEvent) -> dict:
        """
        Обработать событие реактивным слоем.
        
        Returns:
            dict с ключами:
              - reaction: первичная реакция (или None)
              - matched: был ли найден шаблон
              - pattern_id: ID сработавшего шаблона (или None)
              - resonance: резонанс реакции
              - unknown: True, если событие неизвестно (нет шаблона)
        """
        if not self._is_active:
            return {
                "reaction": None,
                "matched": False,
                "pattern_id": None,
                "resonance": None,
                "unknown": True,
                "reason": "reactive_layer_inactive"
            }
        
        # Поиск совпадающего шаблона
        best_pattern: Optional[InstinctPattern] = None
        for pattern in self._patterns:
            if pattern.matches(event):
                if best_pattern is None or pattern.strength > best_pattern.strength:
                    best_pattern = pattern
        
        if best_pattern is not None:
            reaction = best_pattern.activate()
            resonance = SpectralResonance(
                frequency=0.3,  # низкая частота — тьма
                amplitude=best_pattern.strength,
                layer_type=LayerType.DARK,
                metadata={"pattern_id": str(best_pattern.id), "activated": best_pattern.activated_count}
            )
            
            self._activation_log.append({
                "event_id": str(event.id),
                "pattern_id": str(best_pattern.id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            
            return {
                "reaction": reaction,
                "matched": True,
                "pattern_id": best_pattern.id,
                "resonance": resonance,
                "unknown": False,
                "reason": None
            }
        
        # Нет совпадения — событие неизвестно
        resonance = SpectralResonance(
            frequency=0.1,
            amplitude=0.1,
            layer_type=LayerType.DARK,
            metadata={"unknown": True}
        )
        
        return {
            "reaction": None,
            "matched": False,
            "pattern_id": None,
            "resonance": resonance,
            "unknown": True,
            "reason": "no_matching_pattern"
        }
    
    def get_activation_count(self) -> int:
        """Сколько раз сработали шаблоны."""
        return len(self._activation_log)
    
    def get_patterns(self) -> list[InstinctPattern]:
        """Список всех инстинктивных шаблонов."""
        return list(self._patterns)
    
    def stats(self) -> dict:
        """Статистика слоя."""
        return {
            "active": self._is_active,
            "patterns": len(self._patterns),
            "activations": len(self._activation_log),
        }
