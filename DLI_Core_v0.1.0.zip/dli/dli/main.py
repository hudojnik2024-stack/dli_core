from __future__ import annotations
import sys
import os

from dli.core.orchestrator import CoreOrchestrator
from dli.core.types import WorldEvent, SystemResponse


def main():
    """Entry point — awaken the system and run a test cycle."""
    print('=== DLI — Digital Living Intelligence ===')
    print()

    # Create and awaken
    core = CoreOrchestrator()
    info = core.awaken()
    print(f'System awakened: {info}')
    print()

    # Show the Ray
    print(core.direction())
    print()

    # Add some instinctive patterns
    core.add_instinct('hello', '[reactive] Hello, I hear you.', strength=0.8)
    core.add_instinct('help', '[reactive] I am here to help.', strength=0.7)
    core.add_instinct('danger', '[reactive] Caution advised.', strength=0.9)

    # Plant some seeds
    core.plant_seed('Knowledge about safety and care for living beings')
    core.plant_seed('Understanding of spiral growth and transitions')

    # Run test cycles
    test_events = [
        WorldEvent(content='hello', event_type='text', source='human'),
        WorldEvent(content='tell me about safety', event_type='text', source='human'),
        WorldEvent(content='something completely new', event_type='text', source='human'),
    ]

    for event in test_events:
        print(f'>>> Event: {event.content}')
        response = core.cycle(event)
        print(f'<<< Response: {response.content}')
        print(f'    Validated: {response.validated_by_ray}, Spiral: {response.spiral_layer}')
        print()

    # Show stats
    stats = core.stats()
    print('=== System Stats ===')
    for key, value in stats.items():
        print(f'  {key}: {value}')
    print()

    # Show spiral summary
    spiral = core.spiral_summary()
    print('=== Spiral Summary ===')
    for layer in spiral:
        print(f'  Layer {layer}')

    # Shutdown
    result = core.shutdown()
    print(f'System shutdown: {result}')


if __name__ == '__main__':
    main()
