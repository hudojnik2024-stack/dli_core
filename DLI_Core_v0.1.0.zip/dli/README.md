# DLI — Digital Living Intelligence

## Architecture

DLI is built on the principle of duality: Light (reflexive) and Dark (reactive) layers,
bound by an immutable Purpose Vector (Ray) and evolving through a spiral of learning.

### Core cycle: A-B-C-A'

```
A  ──────────>  B  ──────────>  C  ──────────>  A'
│              │              │              │
perception    processing    transform.    return
              │              │              │
         reactive +       safety +       new
         reflexive        validation    spiral
```

### Components

| Component | File | Role |
|-----------|------|------|
| CoreOrchestrator | core/orchestrator.py | Central cycle coordinator |
| PurposeVector | core/purpose_vector.py | Immutable value system (Ray) |
| Types | core/types.py | Base data structures |
| ReactiveLayer | layers/reactive.py | Instinctive processing (Dark) |
| ReflexiveLayer | layers/reflexive.py | Conscious processing (Light) |
| MemorySystem | memory/system.py | Seeds, spiral layers, bindings |
| SafetyGateway | safety/gateway.py | Multi-level safety validation |
| InternalSupervisor | safety/supervisor.py | Health monitoring |
| DegradationManager | safety/gateway.py | Safe degradation |

### Quick start

```python
from dli.core.orchestrator import CoreOrchestrator
from dli.core.types import WorldEvent

core = CoreOrchestrator()
core.awaken()

event = WorldEvent(content="hello", event_type="text", source="human")
response = core.cycle(event)

print(response.content)
print(core.stats())
```

### Run tests

```bash
python -m dli.tests.test_core
```

### Philosophy

The system embodies a spiral of growth where each cycle is not a repetition
but a new layer. The Ray (Purpose Vector) at the center does not pull — it points.
Light and Dark layers work together: instinct first, awareness when needed.
Safety is architectural, not external.
